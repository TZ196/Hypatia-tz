"""
Iridium NEXT (第二代)

轨道参数来源：FCC IBFS S1297; ITU: IRIDIUM-LEO; FCC DA 19-1296

高度 780 km, 倾角 86.4°, 6 轨道面 × 11 星/面, 共 66 颗卫星
Walker-Star 构型，相位差 F=2，最低仰角 8.2°
"""
import math
import sys
from pathlib import Path

try:
    from .main_helper import MainHelper
except ImportError:
    from main_helper import MainHelper

# WGS72 椭球体半径; 取自 https://geographiclib.sourceforge.io/html/NET/NETGeographicLib_8h_source.html
EARTH_RADIUS = 6378135.0

# ============================================================
# 星座参数
# ============================================================

BASE_NAME = "iridium_780"
NICE_NAME = "Iridium-780"
DEFAULT_GENERATED_DATA_DIR = Path(__file__).resolve().parents[2] / "experiments" / BASE_NAME / "gen_data"

ECCENTRICITY = 0.0000001        # 近圆轨道（pyephem 不允许正圆，取极小值）
ARG_OF_PERIGEE_DEGREE = 0.0      # 近地点辐角
PHASE_DIFF = True                # 启用 Walker 星座相位差

# 轨道参数 [1]
MEAN_MOTION_REV_PER_DAY = 14.36  # 平均运动 (圈/天) — 高度 ~780 km
ALTITUDE_M = 780000              # 轨道高度 (m)

# 最低仰角 8.2°（Iridium FCC 申请值）
SATELLITE_CONE_RADIUS_M = ALTITUDE_M / math.tan(math.radians(8.2))
MAX_GSL_LENGTH_M = math.sqrt(math.pow(SATELLITE_CONE_RADIUS_M, 2) + math.pow(ALTITUDE_M, 2))

# ISL 不可低于 80 km 高度，避免大气衰减
MAX_ISL_LENGTH_M = 2 * math.sqrt(
    math.pow(EARTH_RADIUS + ALTITUDE_M, 2) - math.pow(EARTH_RADIUS + 80000, 2)
)

NUM_ORBS = 6                     # 轨道面数
NUM_SATS_PER_ORB = 11            # 每面卫星数
INCLINATION_DEGREE = 86.4        # 倾角 (°) — 近极轨 (Walker-Star)

# ============================================================
# 初始化生成器
# ============================================================

main_helper = MainHelper(
    BASE_NAME,
    NICE_NAME,
    ECCENTRICITY,
    ARG_OF_PERIGEE_DEGREE,
    PHASE_DIFF,
    MEAN_MOTION_REV_PER_DAY,
    ALTITUDE_M,
    MAX_GSL_LENGTH_M,
    MAX_ISL_LENGTH_M,
    NUM_ORBS,
    NUM_SATS_PER_ORB,
    INCLINATION_DEGREE,
)


def main():
    """命令行入口: python main_iridium_780.py <时长s> <步长ms> <ISL模式> <地面站> <路由算法> <线程数>"""
    args = sys.argv[1:]
    if len(args) != 6:
        print("必须提供 6 个参数")
        print("用法: python main_iridium_780.py [时长(s)] [步长(ms)] "
              "[isls_plus_grid / isls_none] "
              "[ground_stations_top_100 / ground_stations_paris_moscow_grid] "
              "[algorithm_free_one_only_over_isls / "
              "algorithm_free_one_only_gs_relays / "
              "algorithm_paired_many_only_over_isls] "
              "[线程数]")
        exit(1)
    else:
        main_helper.calculate(
            str(DEFAULT_GENERATED_DATA_DIR),
            int(args[0]),
            int(args[1]),
            args[2],
            args[3],
            args[4],
            int(args[5]),
        )


if __name__ == "__main__":
    main()
