"""
OneWeb Phase 1 Eutelsat OneWeb — 极轨壳 (近极轨)

轨道参数来源：FCC DA-23-362; SAT-MPL-20200526-00062; ITU: L5/MCSAT-LEO

高度 1200 km, 倾角 87.9°, 12 轨道面 × 49 星/面, 共 588 颗卫星
Walker-Star 构型，最低仰角 5°
"""
import math
import sys
from pathlib import Path

try:
    from .main_helper import MainHelper
except ImportError:
    from main_helper import MainHelper

# WGS72 椭球体半径; 取自 https://geographiclib.sourceforge.io/html/NET/NETGeographicLib_8h_source.html
EARTH_RADIUS = 6378135.0

# ============================================================
# 星座参数
# ============================================================

BASE_NAME = "oneweb_1200_polar"
NICE_NAME = "OneWeb-1200-Polar"
DEFAULT_GENERATED_DATA_DIR = Path(__file__).resolve().parents[2] / "experiments" / BASE_NAME / "gen_data"

ECCENTRICITY = 0.0000001        # 近圆轨道（pyephem 不允许正圆，取极小值）
ARG_OF_PERIGEE_DEGREE = 0.0      # 近地点辐角
PHASE_DIFF = True                # 启用 Walker 星座相位差

# 轨道参数 [1]
MEAN_MOTION_REV_PER_DAY = 13.18  # 平均运动 (圈/天) — 高度 ~1200 km
ALTITUDE_M = 1200000             # 轨道高度 (m)

# 最低仰角 5°（OneWeb 极轨 FCC 申请值）
SATELLITE_CONE_RADIUS_M = ALTITUDE_M / math.tan(math.radians(5.0))
MAX_GSL_LENGTH_M = math.sqrt(math.pow(SATELLITE_CONE_RADIUS_M, 2) + math.pow(ALTITUDE_M, 2))

# ISL 不可低于 80 km 高度，避免大气衰减
MAX_ISL_LENGTH_M = 2 * math.sqrt(
    math.pow(EARTH_RADIUS + ALTITUDE_M, 2) - math.pow(EARTH_RADIUS + 80000, 2)
)

NUM_ORBS = 12                    # 轨道面数
NUM_SATS_PER_ORB = 49            # 每面卫星数
INCLINATION_DEGREE = 87.9        # 倾角 (°) — 近极轨

# ============================================================
# 初始化生成器
# ============================================================

main_helper = MainHelper(
    BASE_NAME,
    NICE_NAME,
    ECCENTRICITY,
    ARG_OF_PERIGEE_DEGREE,
    PHASE_DIFF,
    MEAN_MOTION_REV_PER_DAY,
    ALTITUDE_M,
    MAX_GSL_LENGTH_M,
    MAX_ISL_LENGTH_M,
    NUM_ORBS,
    NUM_SATS_PER_ORB,
    INCLINATION_DEGREE,
)


def main():
    """命令行入口: python main_oneweb_1200_polar.py <时长s> <步长ms> <ISL模式> <地面站> <路由算法> <线程数>"""
    args = sys.argv[1:]
    if len(args) != 6:
        print("必须提供 6 个参数")
        print("用法: python main_oneweb_1200_polar.py [时长(s)] [步长(ms)] "
              "[isls_plus_grid / isls_none] "
              "[ground_stations_top_100 / ground_stations_paris_moscow_grid] "
              "[algorithm_free_one_only_over_isls / "
              "algorithm_free_one_only_gs_relays / "
              "algorithm_paired_many_only_over_isls] "
              "[线程数]")
        exit(1)
    else:
        main_helper.calculate(
            str(DEFAULT_GENERATED_DATA_DIR),
            int(args[0]),
            int(args[1]),
            args[2],
            args[3],
            args[4],
            int(args[5]),
        )


if __name__ == "__main__":
    main()
